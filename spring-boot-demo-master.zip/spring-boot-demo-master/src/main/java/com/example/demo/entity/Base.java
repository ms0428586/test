package com.example.demo.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class Base {

	private String create_by;
	private String create_time;
	private String update_by;
	private String update_time;

}
