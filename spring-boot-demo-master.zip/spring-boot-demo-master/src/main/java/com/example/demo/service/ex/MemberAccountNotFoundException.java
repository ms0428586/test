package com.example.demo.service.ex;

public class MemberAccountNotFoundException extends ServiceException {

	private static final long serialVersionUID = -1428838111704576823L;

	public MemberAccountNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MemberAccountNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MemberAccountNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MemberAccountNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MemberAccountNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
