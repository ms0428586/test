package com.example.demo.dao;

import java.util.List;

import com.example.demo.entity.County;

public interface CountyDao {

	public List<County> findAllCounty();

}
