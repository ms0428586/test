$(() => {
	var message = $("#MESSAGE").val();
	if(message != "" && message != undefined) {
		alert(message);
	}
})