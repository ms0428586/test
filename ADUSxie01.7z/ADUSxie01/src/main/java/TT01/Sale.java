package TT01;

import java.sql.Date;

public class Sale {
	private int id;
	private String shop;
	private String meals;
	private String score;
	private String task;
	
	
	protected Sale() {
		
	}
	
	protected Sale(String shop, String meals, 
			String score, String task) {
		this.shop=shop;
		this.meals=meals;
		this.score=score;
		this.task=task;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getShop() {
		return shop;
	}

	public void setShop(String shop) {
		this.shop = shop;
	}

	public String getMeals() {
		return meals;
	}

	public void setMeals(String meals) {
		this.meals = meals;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public String getTask() {
		return task;
	}

	public void setTask(String task) {
		this.task = task;
	}

	
	

}
