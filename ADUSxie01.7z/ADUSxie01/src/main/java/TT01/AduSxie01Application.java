package TT01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AduSxie01Application {

	public static void main(String[] args) {
		SpringApplication.run(AduSxie01Application.class, args);
	}

}
