package tw.org.iii.cma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabbootJspApplication {
	public static void main(String[] args) {
		SpringApplication.run(LabbootJspApplication.class, args);
	}
}
