package org.LKMS.SpringBootJDBC.mapper;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.LKMS.SpringBootJDBC.model.RecordInfo;
import org.springframework.jdbc.core.RowMapper;

public class RecordMapper implements RowMapper<RecordInfo>{
	public static final String BASE_SQL //
		="SELECT RD.ID, RD.STORE, RD.MEALS, RD.SCORE, RD.EXPERIENCE, RD.TASK, RD.DATE From record RD";
	@Override
	public RecordInfo mapRow(ResultSet rs, int rowNum) throws SQLException {

		Long id = rs.getLong("ID");
		String productStore = rs.getString("STORE");
		String productMeals = rs.getString("MEALS");
		String productScore = rs.getString("SCORE");
		String productExperience = rs.getString("EXPERIENCE");
		String productTask = rs.getString("TASK");
		Date productDate = rs.getDate("DATE");

	return new RecordInfo(id, productStore, productMeals,productScore,productExperience,productTask,productDate);
}

}
