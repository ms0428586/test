package org.LKMS.SpringBootJDBC.dao;

import java.util.List;
import javax.sql.DataSource;
import org.LKMS.SpringBootJDBC.mapper.MenuMapper;
import org.LKMS.SpringBootJDBC.model.MenuInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
@Repository
public class delMenuDAO  extends JdbcDaoSupport{
	@Autowired
	public delMenuDAO(DataSource dataSource) {
		this.setDataSource(dataSource);
	}

	public List<MenuInfo> getMenu() {
		
		String sql = MenuMapper.BASE_SQL;

		Object[] params = new Object[] {};
		MenuMapper mapper = new MenuMapper();
		List<MenuInfo> list = this.getJdbcTemplate().query(sql, params, mapper);
	 
		return list;
	}
	public void delMenu(Long newId,String newproductCode ,String newproductName,String newproductSize,
			double newproductPrice,String newproductCategory,String newproductDescription) {
		System.out.println("SQL-----------");
		String sqlDel ="delete from menu WHERE id=? ";
		this.getJdbcTemplate().update(sqlDel,newId,newproductCode,newproductName,newproductSize,newproductPrice,newproductCategory,newproductDescription);
		System.out.println("SQL-----------");
	}

}
