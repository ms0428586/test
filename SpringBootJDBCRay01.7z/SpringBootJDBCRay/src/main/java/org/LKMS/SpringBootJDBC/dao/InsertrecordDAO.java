package org.LKMS.SpringBootJDBC.dao;

import java.sql.Date;
import java.util.List;
import javax.sql.DataSource;
import org.LKMS.SpringBootJDBC.mapper.RecordMapper;
import org.LKMS.SpringBootJDBC.model.RecordInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class InsertrecordDAO extends JdbcDaoSupport {
	@Autowired
	public InsertrecordDAO(DataSource dataSource) {
		this.setDataSource(dataSource);
	}

	public List<RecordInfo> getMenu() {
		
		String sql = RecordMapper.BASE_SQL;

		Object[] params = new Object[] {};
		RecordMapper mapper = new RecordMapper();
		List<RecordInfo> list = this.getJdbcTemplate().query(sql, params, mapper);
	 
		return list;
	}
	
	public void AddRecord(String newStore ,String newMeals,String newScore,
			String newExperience,String newTask,Date newDate) {
		System.out.println("SQL-----------");
		String sqlInsert ="INSERT INTO record(STORE,MEALS, SCORE,EXPERIENCE,TASK, DATE ) VALUES (?,?,?,?,?,?,?)";
		this.getJdbcTemplate().update(sqlInsert,newStore,newMeals,newScore,newExperience,newTask,newDate);
		System.out.println("SQL-----------");
	}

}
