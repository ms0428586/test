package org.LKMS.SpringBootJDBC.model;

public class RecordInfo {

}
