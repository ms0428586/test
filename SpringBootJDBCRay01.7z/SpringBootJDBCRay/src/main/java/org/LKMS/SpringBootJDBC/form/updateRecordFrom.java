package org.LKMS.SpringBootJDBC.form;

public class updateRecordFrom {

}
