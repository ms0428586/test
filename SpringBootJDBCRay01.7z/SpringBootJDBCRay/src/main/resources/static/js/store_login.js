function login() {
    window.location.href = "store__management.html"


}