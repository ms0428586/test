/**
 * 
 */
function login() {
    window.location.href = "member_order.html"


}