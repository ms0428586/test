//package org.LKMS.SpringBootJDBC.controller;
//
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
//
//@Controller
//public class appcontroller {
//    @GetMapping("/webplatform_frontpage")
//    public String hello(Model model) {
//    	model.addAttribute("hello", "Hello World!!!"); // （變數名稱，變數值)
//      
//        return "webplatform_frontpage"; // 要導入的html
//    } 
//    
//    
//    
//}